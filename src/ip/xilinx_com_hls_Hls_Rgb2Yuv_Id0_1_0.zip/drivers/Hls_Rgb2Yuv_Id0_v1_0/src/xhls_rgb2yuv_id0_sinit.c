// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xhls_rgb2yuv_id0.h"

extern XHls_rgb2yuv_id0_Config XHls_rgb2yuv_id0_ConfigTable[];

XHls_rgb2yuv_id0_Config *XHls_rgb2yuv_id0_LookupConfig(u16 DeviceId) {
	XHls_rgb2yuv_id0_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XHLS_RGB2YUV_ID0_NUM_INSTANCES; Index++) {
		if (XHls_rgb2yuv_id0_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XHls_rgb2yuv_id0_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHls_rgb2yuv_id0_Initialize(XHls_rgb2yuv_id0 *InstancePtr, u16 DeviceId) {
	XHls_rgb2yuv_id0_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHls_rgb2yuv_id0_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHls_rgb2yuv_id0_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

