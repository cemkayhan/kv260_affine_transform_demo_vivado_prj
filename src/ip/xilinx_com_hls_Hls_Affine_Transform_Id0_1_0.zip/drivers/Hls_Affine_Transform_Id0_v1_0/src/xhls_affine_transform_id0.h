// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XHLS_AFFINE_TRANSFORM_ID0_H
#define XHLS_AFFINE_TRANSFORM_ID0_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xhls_affine_transform_id0_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u32 Ctrl_BaseAddress;
} XHls_affine_transform_id0_Config;
#endif

typedef struct {
    u32 Ctrl_BaseAddress;
    u32 IsReady;
} XHls_affine_transform_id0;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHls_affine_transform_id0_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHls_affine_transform_id0_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHls_affine_transform_id0_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHls_affine_transform_id0_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XHls_affine_transform_id0_Initialize(XHls_affine_transform_id0 *InstancePtr, u16 DeviceId);
XHls_affine_transform_id0_Config* XHls_affine_transform_id0_LookupConfig(u16 DeviceId);
int XHls_affine_transform_id0_CfgInitialize(XHls_affine_transform_id0 *InstancePtr, XHls_affine_transform_id0_Config *ConfigPtr);
#else
int XHls_affine_transform_id0_Initialize(XHls_affine_transform_id0 *InstancePtr, const char* InstanceName);
int XHls_affine_transform_id0_Release(XHls_affine_transform_id0 *InstancePtr);
#endif

void XHls_affine_transform_id0_Start(XHls_affine_transform_id0 *InstancePtr);
u32 XHls_affine_transform_id0_IsDone(XHls_affine_transform_id0 *InstancePtr);
u32 XHls_affine_transform_id0_IsIdle(XHls_affine_transform_id0 *InstancePtr);
u32 XHls_affine_transform_id0_IsReady(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_EnableAutoRestart(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_DisableAutoRestart(XHls_affine_transform_id0 *InstancePtr);

void XHls_affine_transform_id0_Set_width(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_width(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_height(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_height(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_padWidth(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_padWidth(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_padHeight(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_padHeight(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_vidWrAxi(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_vidWrAxi(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_affRdAxi(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_affRdAxi(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_affWrAxi(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_affWrAxi(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_vidRdAxi(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_vidRdAxi(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_rotMat00(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_rotMat00(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_rotMat01(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_rotMat01(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_rotMat02(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_rotMat02(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_rotMat10(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_rotMat10(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_rotMat11(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_rotMat11(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_Set_rotMat12(XHls_affine_transform_id0 *InstancePtr, u32 Data);
u32 XHls_affine_transform_id0_Get_rotMat12(XHls_affine_transform_id0 *InstancePtr);

void XHls_affine_transform_id0_InterruptGlobalEnable(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_InterruptGlobalDisable(XHls_affine_transform_id0 *InstancePtr);
void XHls_affine_transform_id0_InterruptEnable(XHls_affine_transform_id0 *InstancePtr, u32 Mask);
void XHls_affine_transform_id0_InterruptDisable(XHls_affine_transform_id0 *InstancePtr, u32 Mask);
void XHls_affine_transform_id0_InterruptClear(XHls_affine_transform_id0 *InstancePtr, u32 Mask);
u32 XHls_affine_transform_id0_InterruptGetEnabled(XHls_affine_transform_id0 *InstancePtr);
u32 XHls_affine_transform_id0_InterruptGetStatus(XHls_affine_transform_id0 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
