// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// ctrl
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of width
//        bit 11~0 - width[11:0] (Read/Write)
//        others   - reserved
// 0x14 : reserved
// 0x18 : Data signal of height
//        bit 11~0 - height[11:0] (Read/Write)
//        others   - reserved
// 0x1c : reserved
// 0x20 : Data signal of padWidth
//        bit 11~0 - padWidth[11:0] (Read/Write)
//        others   - reserved
// 0x24 : reserved
// 0x28 : Data signal of padHeight
//        bit 11~0 - padHeight[11:0] (Read/Write)
//        others   - reserved
// 0x2c : reserved
// 0x30 : Data signal of vidWrAxi
//        bit 31~0 - vidWrAxi[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of affRdAxi
//        bit 31~0 - affRdAxi[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of affWrAxi
//        bit 31~0 - affWrAxi[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of vidRdAxi
//        bit 31~0 - vidRdAxi[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of rotMat00
//        bit 31~0 - rotMat00[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of rotMat01
//        bit 31~0 - rotMat01[31:0] (Read/Write)
// 0x5c : reserved
// 0x60 : Data signal of rotMat02
//        bit 31~0 - rotMat02[31:0] (Read/Write)
// 0x64 : reserved
// 0x68 : Data signal of rotMat10
//        bit 31~0 - rotMat10[31:0] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of rotMat11
//        bit 31~0 - rotMat11[31:0] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of rotMat12
//        bit 31~0 - rotMat12[31:0] (Read/Write)
// 0x7c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_AP_CTRL        0x00
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_GIE            0x04
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_IER            0x08
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_ISR            0x0c
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_WIDTH_DATA     0x10
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_WIDTH_DATA     12
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_HEIGHT_DATA    0x18
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_HEIGHT_DATA    12
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_PADWIDTH_DATA  0x20
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_PADWIDTH_DATA  12
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_PADHEIGHT_DATA 0x28
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_PADHEIGHT_DATA 12
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_VIDWRAXI_DATA  0x30
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_VIDWRAXI_DATA  32
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_AFFRDAXI_DATA  0x38
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_AFFRDAXI_DATA  32
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_AFFWRAXI_DATA  0x40
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_AFFWRAXI_DATA  32
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_VIDRDAXI_DATA  0x48
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_VIDRDAXI_DATA  32
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_ROTMAT00_DATA  0x50
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_ROTMAT00_DATA  32
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_ROTMAT01_DATA  0x58
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_ROTMAT01_DATA  32
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_ROTMAT02_DATA  0x60
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_ROTMAT02_DATA  32
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_ROTMAT10_DATA  0x68
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_ROTMAT10_DATA  32
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_ROTMAT11_DATA  0x70
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_ROTMAT11_DATA  32
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_ADDR_ROTMAT12_DATA  0x78
#define XHLS_AFFINE_TRANSFORM_ID0_CTRL_BITS_ROTMAT12_DATA  32

